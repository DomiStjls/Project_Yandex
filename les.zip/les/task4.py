from flask import Flask, request, url_for

app = Flask(__name__)


@app.route("/")
def base():
    return "Миссия Колонизация Марса!"


@app.route("/index")
def index():
    return """
    <!doctype html>
    <html lang="en">

  <head>
  <nav class="navbar navbar-expand-lg bg-body-tertiary">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Navbar</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="Promotion">Promotion</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Link</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Dropdown
          </a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="#">Action</a></li>
            <li><a class="dropdown-item" href="#">Another action</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="#">Something else here</a></li>
          </ul>
        </li>
        <li class="nav-item">
          <a class="nav-link disabled" aria-disabled="true">Disabled</a>
        </li>
      </ul>
      <form class="d-flex" role="search">
        <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
        <button class="btn btn-outline-success" type="submit">Search</button>
      </form>
    </div>
  </div>
</nav>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Web project</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
  </head>
  <body>
    <h1>Привет, Яндекс</h1>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
  </body>
</html>"""


@app.route("/image_mars")
def image_mars():
    return """
    <!doctype html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <link rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css"
        integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1"
        crossorigin="anonymous">
        <link rel="stylesheet" href="./static/css/style.css">
        <title>Привет, Марс!</title>
    </head>
        <html lang="en">
        <body>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
        <h1 style="color: red;">Жди нас, Марс!</h1>
        <img src='./static/img/image_mars.png'>
        <p class='p1'>Человечество вырастает из детства.</p>
        <p class='p2'>Человечеству мала одна планета.</p>
        <p class='p3'>Мы сделаем обитаемыми безжизненные пока планеты.</p>
        <p class='p4'>И начнем с Марса!</p>
        <p class='p5'>Присоединяйся!</p>


        </body>
        </html>
        """


@app.route("/astronaut_selection", methods=["POST", "GET"])
def form_sample():
    if request.method == "GET":
        return """
        <!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet"
    href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css"
    integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1"
    crossorigin="anonymous">
    <link rel="stylesheet" href="./static/css/style.css">
    <title>Анкета</title>
</head>
<body>
    <h1>Анкета участника</h1>
    <div>
        <form class="login_form" method="post">
            <input type="text" class="form-control" id="text" placeholder="Введите фамилию" name="text">
            <input type="text" class="form-control" id="text" placeholder="Введите имя" name="text">
            <input type="email" class="form-control" id="email" aria-describedby="emailHelp" placeholder="Введите адрес почты" name="email">
            <div class="form-group">
                <label for="classSelect">Ваше образование</label>
                <select class="form-control" id="classSelect" name="class">
                  <option>Начальное</option>
                  <option>Среднее</option>
                  <option>Высшее</option>
              </select>
          </div>
          <div>
            <label for="classSelect">Ваши профессии</label>
            <p>
              <input type="checkbox" class="form-check-input" id="acceptRules" name="accept">
              <label class="form-check-label" for="acceptRules">инженер-исследователь</label>
          </p>
          <p>
              <input type="checkbox" class="form-check-input" id="acceptRules" name="accept">
              <label class="form-check-label" for="acceptRules">пилот</label>
          </p>
          <p>
              <input type="checkbox" class="form-check-input" id="acceptRules" name="accept">
              <label class="form-check-label" for="acceptRules">строитель</label>
          </p>
          <p>
              <input type="checkbox" class="form-check-input" id="acceptRules" name="accept">
              <label class="form-check-label" for="acceptRules">экзобиолог</label>
          </p>
          <p>
              <input type="checkbox" class="form-check-input" id="acceptRules" name="accept">
              <label class="form-check-label" for="acceptRules">врач</label>
          </p>
          <p>
              <input type="checkbox" class="form-check-input" id="acceptRules" name="accept">
              <label class="form-check-label" for="acceptRules">инженер по терраформированию</label>
          </p>
          <p>
              <input type="checkbox" class="form-check-input" id="acceptRules" name="accept">
              <label class="form-check-label" for="acceptRules">гляциолог</label>
          </p>
          <p>
              <input type="checkbox" class="form-check-input" id="acceptRules" name="accept">
              <label class="form-check-label" for="acceptRules">оператор марсохода</label>
          </p>
          <p>
              <input type="checkbox" class="form-check-input" id="acceptRules" name="accept">
              <label class="form-check-label" for="acceptRules">киберинженер</label>
          </p>
          <p>
              <input type="checkbox" class="form-check-input" id="acceptRules" name="accept">
              <label class="form-check-label" for="acceptRules">штурман</label></p>
              <p><input type="checkbox" class="form-check-input" id="acceptRules" name="accept">
                  <label class="form-check-label" for="acceptRules">пилот дронов</label></p>
              </div>

              <div class="form-group">
                <label for="about">Почему вы хотите принять участие в миссии?</label>
                <textarea class="form-control" id="about" rows="3" name="about"></textarea>
            </div>
            <div class="form-group">
                <label for="photo">Приложите фотографию</label>
                <input type="file" class="form-control-file" id="photo" name="file">
            </div>
            <div class="form-group">
                <label for="form-check">Укажите пол</label>
                <div class="form-check">
                  <input class="form-check-input" type="radio" name="sex" id="male" value="male" checked>
                  <label class="form-check-label" for="male">
                    Мужской
                </label>
            </div>
            <div class="form-check">
              <input class="form-check-input" type="radio" name="sex" id="female" value="female">
              <label class="form-check-label" for="female">
                Женский
            </label>
        </div>
    </div>
    <div class="form-group form-check">
        <input type="checkbox" class="form-check-input" id="acceptRules" name="accept">
        <label class="form-check-label" for="acceptRules">Готовы остаться на Марсе?</label>
    </div>
    <button type="submit" class="btn btn-primary">Отправить</button>
</form>
</div>
</body>
</html>


        """
    elif request.method == "POST":
        print(request.form["email"])
        print(request.form["text"])
        print(request.form["class"])
        print(request.form["file"])
        print(request.form["about"])
        print(request.form["accept"])
        print(request.form["sex"])
        return "Форма отправлена"

if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')
